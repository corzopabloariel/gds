<section>
    <div id="carouselExampleIndicators mb-2" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <?php for($i = 0 ; $i < count($slider) ; $i++): ?>
                <?php if($i == 0): ?>
                    <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>" class="active"></li>
                <?php else: ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>"></li>
                <?php endif; ?>
            <?php endfor; ?>
        </ol>
        <div class="carousel-inner">
            <?php for($i = 0 ; $i < count($slider) ; $i++): ?>
                <?php if($i == 0): ?>
                    <div class="carousel-item active">
                <?php else: ?>
                    <div class="carousel-item">
                <?php endif; ?>
                <img class="d-block w-100" src="<?php echo e(asset($slider[$i]['img'])); ?>" >
                <div class="position-absolute w-100">
                    <div class="container">
                        <?php echo $slider[$i]['texto']; ?>

                    </div>
                </div>
            </div>
            <?php endfor; ?>
        </div>
    
        
    </div>
    <div class="wrapper-empresa py-4">
        <div class="container">
            <h3 class=title><?php echo e($contenido["acerca"]["titulo"]); ?></h3>
            <div class="row mt-2">
                <div class="col-md-6 col-12">
                <?php echo $contenido["acerca"]["texto"]; ?>

                </div>
                <div class="col-md-6 col-12">
                    <ul class="list-unstyled numeros">
                    <?php $__currentLoopData = $contenido["acerca"]["opciones"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="d-flex align-items-center"><span class="mr-2"><?php echo e($o["numero"]); ?></span><?php echo e($o["nombre"]); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-6 col-12">
                    <div class="p-3 shadow">
                        <h4 class="title"><?php echo e($contenido["mision"]["titulo"]); ?></h4>
                        <?php echo $contenido["mision"]["texto"]; ?>

                    </div>
                </div>
                <div class="col-md-6 col-12">
                    <div class="p-3 shadow">
                        <h4 class="title"><?php echo e($contenido["valor"]["titulo"]); ?></h4>
                        <?php echo $contenido["valor"]["texto"]; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /* C:\Users\Pablo\Desktop\gds\resources\views/page/element/empresa.blade.php */ ?>