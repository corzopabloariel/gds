<section class="wrapper-proyectos">
    <div class="container">
        <div class="row py-3">
            <div class="col-12">
                <h3 class="title">Proyectos</h3>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(URL::to('proyectos/'. $v['id'])); ?>" class="col-md-4 col-12 my-3" href="">
                    <?php
                    $imgData = json_decode($v['img']);
                    $img = null;
                    if(count($imgData) > 0)
                        $img = $imgData[0];
                    ?>
                    <img src="<?php echo e(asset($img)); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" />
                    <p class="mb-0"><?php echo e($v["titulo"]); ?></p>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /* C:\Users\Pablo\Desktop\gds\resources\views/page/element/proyectos.blade.php */ ?>