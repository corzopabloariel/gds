<section>
    <div id="carouselExampleIndicators mb-2" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <?php for($i = 0 ; $i < count($slider) ; $i++): ?>
                <?php if($i == 0): ?>
                    <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>" class="active"></li>
                <?php else: ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>"></li>
                <?php endif; ?>
            <?php endfor; ?>
        </ol>
        <div class="carousel-inner">
            <?php for($i = 0 ; $i < count($slider) ; $i++): ?>
                <?php if($i == 0): ?>
                    <div class="carousel-item active">
                <?php else: ?>
                    <div class="carousel-item">
                <?php endif; ?>
                <img class="d-block w-100" src="<?php echo e(asset($slider[$i]['img'])); ?>" >
                <div class="position-absolute w-100">
                    <div class="container">
                        <?php echo $slider[$i]['texto']; ?>

                    </div>
                </div>
            </div>
            <?php endfor; ?>
        </div>
    
        
    </div>
    <div class="wrapper-destacados py-4">
        <h3 class="title text-uppercase text-center mb-2">productos destacados</h3>
        <div class="container">
            <div class="row justify-content-md-center">
                <div class="col-md-3 col-6">
                    <a href="<?php echo e(route('ecobruma')); ?>">
                        <img src="<?php echo e($ecobruma); ?>" alt="" class="w-100" srcset="">
                        <p class="m-0 p-2">Ecobruma</p>
                    </a>
                </div>
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $p["data"] = json_decode($p["data"], true);
                    $p["imagenes"] = $p->imagenes;
                    $p["familia_id"] = App\Familia::find($p["familia_id"])["titulo"];
                    $img = null;
                    if(count($p["imagenes"]) > 0)
                        $img = $p["imagenes"][0]["img"];
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 col-6">
                    <a href="">
                        <img src="<?php echo e($img); ?>" alt="" class="w-100" srcset="">
                        <p class="m-0 p-2"><?php echo e($p["titulo"]); ?></p>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="wrapper-home py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-12">
                    <img src="<?php echo e(asset($contenido['img'])); ?>" class="d-block w-100" alt="GDS Home">
                </div>
                <div class="col-md-6 col-12">
                    <h3 class="title"><?php echo $contenido["titulo"]; ?></h3>
                    <?php echo $contenido["texto"]; ?>

                    <ul class="list-unstyled caracteristicas">
                        <?php $__currentLoopData = $contenido["opciones"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="d-flex align-items-center"><img src="<?php echo e(asset($c['img'])); ?>" class="mr-2"/><?php echo e($c["titulo"]); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /* C:\Users\Pablo\Desktop\gds\resources\views/page/element/home.blade.php */ ?>