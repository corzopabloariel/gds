@extends('elementos.main')

@section('headTitle', 'Bienvenido | GDS')
@section('bodyTitle', 'Bienvenido')

@section('body')
<div class="d-flex align-items-center justify-content-center" style="height: 100vh;">
    <h1>Bienvenido</h1>
</div>
@endsection