<section class="wrapper-producto">
    <div class="container">
        <div class="row py-3">
            <div class="col-12">
                <p class="title"><a href="<?php echo e(route('productos')); ?>">Productos</a> | <a href="<?php echo e(URL::to('productos/'. $producto['familia_id'])); ?>"><?php echo e($menu[$producto["familia_id"]]["titulo"]); ?></a> | <?php echo e($menu[$producto["familia_id"]]["hijos"][$producto["id"]]["titulo"]); ?></p>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="sidebar">
                    <ul class="list-group">
                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-familia="<?php echo e($k); ?>" class="list-group-item">
                                <span class="d-block position-relative"><a href="<?php echo e(URL::to('productos/'. $k)); ?>"><?php echo e($v["titulo"]); ?></a><i class="fas fa-angle-down position-absolute"></i><i class="fas fa-angle-right position-absolute"></i></span>
                                <?php if(count($v["hijos"]) > 0): ?>
                                <ul class="list-group">
                                    <?php $__currentLoopData = $v["hijos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk => $vv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li data-producto="<?php echo e($kk); ?>" class="list-group-item"><span><a href="<?php echo e(URL::to('productos/' . $vv['tituloLimpio'] . '/'. $kk)); ?>"><?php echo e($vv["titulo"]); ?></a></span></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-md-9 producto mt-sm-2">
                <div class="row justify-content-md-center">
                    <div class="col-md-6">
                        <div id="carouselExampleIndicators mb-2" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <?php for($i = 0 ; $i < count($producto["imagenes"]) ; $i++): ?>
                                    <?php if($i == 0): ?>
                                        <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>" class="active"></li>
                                    <?php else: ?>
                                    <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>"></li>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </ol>
                            <div class="carousel-inner">
                                <?php for($i = 0 ; $i < count($producto["imagenes"]) ; $i++): ?>
                                    <?php if($i == 0): ?>
                                        <div class="carousel-item active">
                                    <?php else: ?>
                                        <div class="carousel-item">
                                    <?php endif; ?>
                                    <img class="d-block w-100" src="<?php echo e(asset($producto['imagenes'][$i]['img'])); ?>" >
                                </div>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <h3 class="title mt-3"><?php echo e($producto["titulo"]); ?></h3>
                <div class="descripcion">
                    <?php echo $producto["data"]["descripcion"]; ?>

                </div>
                <?php if(count($producto["data"]["caracteristicas"]) > 0): ?>
                <div class="row caracteristicas my-5">
                    <?php $__currentLoopData = $producto["data"]["caracteristicas"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <img class="d-block mx-auto" src="<?php echo e(asset($c['img'])); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" />
                        <p class="w-75 mx-auto text-center"><?php echo e($c["nombre"]); ?></p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
                <div class="detalle">
                    <?php echo $producto["data"]["detalle"]; ?>

                </div>

                <div class="botones">
                    <?php if(!empty($producto['data']['especificaciones'])): ?>
                    <a target="blank" href="<?php echo e(asset($producto['data']['especificaciones'])); ?>" class="btn btn-gds text-uppercase">especificaciones</a>
                    <?php endif; ?>
                    <button class="btn btn-gds text-uppercase">consultar</button>
                </div>

                <?php if(!empty($producto['data']['video'])): ?>
                <div class="video my-5" style="padding: 0 15px">
                    <div class="row justify-content-md-center bg-light border py-4">
                        <div class="col-md-6">
                            <p class="mb-0">Para más información, mirá el video a continuación</p>
                        </div>
                        <div class="col-md-6">
                            <iframe class="w-100" src="https://www.youtube.com/embed/<?php echo e($producto['data']['video']); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <?php if(count($producto["productos"]) > 0): ?>
                <div class="relacionados mt-5">
                    <h4 class="title">Productos Relacionados</h4>
                    <div class="row my-4">
                        <?php $__currentLoopData = $producto["productos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $img = null;
                            $images = $p->imagenes;
                            if(count($images) > 0)
                                $img = $images[0]["img"];
                            $name = $menu[$p["familia_id"]]["hijos"][$p["id"]]["tituloLimpio"];
                        ?>
                        <a href="<?php echo e(URL::to('productos/' . $name . '/'. $p['id'])); ?>" class="col-md-4 col-12 mt-2">
                            <div class="position-relative">
                                <i class="fas fa-plus position-absolute"></i>
                                <div class="position-absolute w-100 h-100"></div>
                                <img src="<?php echo e(asset($img)); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" />
                            </div>
                            <p class="mb-0 p-2"><?php echo e($p["titulo"]); ?></p>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php $__env->startPush('scripts'); ?>
    <script>
        window.producto = <?php echo json_encode($producto, 15, 512) ?>;

        $(document).ready(function() {
            $(`[data-familia="${window.producto.familia_id}"]`).addClass("active-menu");
            $(`[data-producto="${window.producto.id}"]`).addClass("active-menu");
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /* C:\Users\Pablo\Desktop\gds\resources\views/page/element/productoEspecifico.blade.php */ ?>