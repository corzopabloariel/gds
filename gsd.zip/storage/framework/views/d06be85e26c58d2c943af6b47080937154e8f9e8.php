<!DOCTYPE html>
<html>
<body>
	<h2>GSD</h2>
	<h3>Presupuesto</h3> 
	<p>Enviado desde la web</p>
	<br>
	<br>
	<h3>Datos del contacto</h3>
	<ul>
		<li><strong>Nombre:</strong> <?php echo e($nombre); ?></li>
		<li><strong>Télefono:</strong> <?php echo e($telefono); ?></li>
        <li><strong>Localidad:</strong> <?php echo e($localidad); ?></li>
		<li><strong>Email:</strong> <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></li>
	</ul>
    <br>
    <h4>Mensaje:</h4>
    <p><?php echo e($mensaje); ?></p>
</body>
</html>
<?php /* C:\Users\Pablo\Desktop\gds\resources\views/page/form/presupuesto.blade.php */ ?>