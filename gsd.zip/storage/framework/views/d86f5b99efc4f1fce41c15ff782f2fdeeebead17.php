<section class="wrapper-productos py-5">
    <div class="container">
        <div class="row justify-content-md-center">
            <div class="col-md-8 col-12">
                <div class="row">
                    <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(URL::to('productos/'. $v['id'])); ?>" class="col-md-4 col-12 my-3">
                            <div class="position-relative border">
                                <i class="fas fa-plus position-absolute"></i>
                                <div class="position-absolute w-100 h-100"></div>
                                <img src="<?php echo e(asset($v['img'])); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" />
                            </div>
                            <p class="mb-0 mt-2"><?php echo e($v["titulo"]); ?></p>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /* C:\Users\Pablo\Desktop\Laravel\gsd\resources\views/page/element/productos.blade.php */ ?>