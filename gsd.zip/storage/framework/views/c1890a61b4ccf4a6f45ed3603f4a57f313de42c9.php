<section class="wrapper-producto">
    <div class="container">
        <div class="row py-3">
            <div class="col-12">
                <p class="title"><?php echo $nav;; ?></p>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="sidebar">
                    <ul class="list-group">
                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-familia="<?php echo e($k); ?>" class="list-group-item">
                                <span class="d-block position-relative"><a href="<?php echo e(URL::to('productos/'. $k)); ?>"><?php echo e($v["titulo"]); ?></a><i class="fas fa-angle-down position-absolute"></i><i class="fas fa-angle-right position-absolute"></i></span>
                                <?php if(count($v["subcategorias"]) > 0): ?>
                                <ul class="list-group">
                                    <?php $__currentLoopData = $v["subcategorias"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk => $vv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li data-familia="<?php echo e($kk); ?>" class="list-group-item"><a href="<?php echo e(URL::to('productos/' . $kk)); ?>"><?php echo e($vv["titulo"]); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php else: ?>
                                    <?php if(count($v["hijos"]) > 0): ?>
                                    <ul class="list-group">
                                        <?php $__currentLoopData = $v["hijos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk => $vv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item"><a href="<?php echo e(URL::to('productos/' . $vv['tituloLimpio'] . '/'. $kk)); ?>"><?php echo e($vv["titulo"]); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-md-9">
                <div class="row productos mt-sm-2">
                    <?php if(isset($menu[$id])): ?>
                        <?php if(count($menu[$id]["subcategorias"]) > 0): ?>
                            <?php $__currentLoopData = $menu[$id]["subcategorias"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(URL::to('productos/' . $k)); ?>" class="col-md-4 col-12 my-2">
                                    <div class="position-relative border">
                                        <i class="fas fa-plus position-absolute"></i>
                                        <div class="position-absolute w-100 h-100"></div>
                                        <img src="<?php echo e(asset($v['img'])); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" />
                                    </div>
                                    <p class="mb-0 p-2"><?php echo e($v["titulo"]); ?></p>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $img = null;
                            $images = $p->imagenes;
                            if(count($images) > 0)
                                $img = $images[0]["img"];
                            if(is_null($p->familia["padre_id"]))
                                $name = $menu[$familia["id"]]["hijos"][$p["id"]]["tituloLimpio"];
                            else
                                $name = $menu[$p->familia["padre_id"]]["subcategorias"][$p["familia_id"]]["hijos"][$p["id"]]["tituloLimpio"];
                        ?>
                        <a href="<?php echo e(URL::to('productos/' . $name . '/'. $p['id'])); ?>" class="col-md-4 col-12 my-2">
                            <div class="position-relative border">
                                <i class="fas fa-plus position-absolute"></i>
                                <div class="position-absolute w-100 h-100"></div>
                                <img src="<?php echo e(asset($img)); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" />
                            </div>
                            <p class="mb-0 p-2"><?php echo e($p["titulo"]); ?></p>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->startPush('scripts'); ?>
    <script>
        window.familia = <?php echo json_encode($familia, 15, 512) ?>;

        $(document).ready(function() {
            if(window.familia.padre_id !== null)
            $(`[data-familia="${window.familia.padre_id}"]`).addClass("active-menu");
            $(`[data-familia="${window.familia.id}"]`).addClass("active-menu");
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /* C:\Users\Pablo\Desktop\Laravel\gsd\resources\views/page/element/producto.blade.php */ ?>