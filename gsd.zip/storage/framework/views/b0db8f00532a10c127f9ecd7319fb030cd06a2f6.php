<?php $__env->startSection('headTitle', strtoupper($title). ' | GSD'); ?>
<?php $__env->startSection('bodyTitle', $title); ?>

<?php $__env->startSection('body'); ?>
<?php echo $__env->make('page.element.' . $title, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('elementos.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\Pablo\Desktop\Laravel\gsd\resources\views/welcome.blade.php */ ?>