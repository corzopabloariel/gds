<?php $__env->startSection('headTitle', 'Bienvenido | GDS'); ?>
<?php $__env->startSection('bodyTitle', 'Bienvenido'); ?>

<?php $__env->startSection('body'); ?>
<div class="d-flex align-items-center justify-content-center" style="height: 100vh;">
    <h1>Bienvenido</h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('elementos.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\Pablo\Desktop\Laravel\gsd\resources\views/adm/index/index.blade.php */ ?>