<!DOCTYPE html>
<html>
<body>
	<h2>GSD</h2>
	<h3>Contacto</h3> 
	<p>Enviado desde la web</p>
	<br>
	<br>
	<h3>Datos del contacto</h3>
	<ul>
		<li><strong>Nombre:</strong> <?php echo e($nombre); ?> <?php echo e($apellido); ?></li>
		<li><strong>Telefono:</strong> <?php echo e($telefono); ?></li>
		<li><strong>Email:</strong> <?php echo e($email); ?></li>
	</ul>
    <br>
    <h4>Mensaje:</h4>
    <p><?php echo e($mensaje); ?></p>
</body>
</html>
<?php /* C:\Users\Pablo\Desktop\gds\resources\views/page/form/contacto.blade.php */ ?>